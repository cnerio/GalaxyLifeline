<?php 
echo $description = str_replace('EBBP', 'ACP',"T-Mobile EBBP 10GB Plan (Package 1133)");