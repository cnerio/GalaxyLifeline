<?php require APPROOT . '/views/inc/header.php'; ?>
<style>
  body {
  font-weight: 400;
  font-size: 14px;
  line-height: 120%;
  color: #dddee0;
  background-color: #282828;
  background-image: linear-gradient(0deg, transparent 24%, rgba(255, 255, 255, .05) 25%, rgba(255, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, .05) 75%, rgba(255, 255, 255, .05) 76%, transparent 77%, transparent), linear-gradient(90deg, transparent 24%, rgba(255, 255, 255, .05) 25%, rgba(255, 255, 255, .05) 26%, transparent 27%, transparent 74%, rgba(255, 255, 255, .05) 75%, rgba(255, 255, 255, .05) 76%, transparent 77%, transparent);
  background-size: 50px 50px;
  padding: 0;
  margin: 0;
  height: 100%;
}

</style>
<div class="container">
        <div class="row" style="padding: 80px;padding-bottom: 30px;">
            <div class="col-md-6 col-lg-6 text-center text-md-end text-lg-end text-xl-end"><img class="img-fluid" src="<?php echo URLROOT; ?>/img/laptop.png"></div>
            <div class="col-md-6 col-lg-6 d-md-flex d-xl-flex align-items-md-center align-items-xl-center">
                <h1 class="d-xl-flex" style="font-family: 'Share Tech', sans-serif;margin-top: 20px;margin-bottom: 30px;font-weight: bold;text-align: left;font-size: 36px;">Our Site is under Construction,&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Come Back Soon !</h1>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <p style="padding: 20px;text-align: center;">Thank you for being patient. Our Site is under Construction.</p>
            </div>
        </div>
    </div>
  
<?php //require APPROOT . '/views/inc/footer.php'; ?>
